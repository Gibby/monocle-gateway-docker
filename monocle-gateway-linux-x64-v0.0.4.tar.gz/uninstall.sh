#!/bin/bash -e
# *********************************************************************
#              __  __  ___  _  _  ___   ___ _    ___
#             |  \/  |/ _ \| \| |/ _ \ / __| |  | __|
#             | |\/| | (_) | .` | (_) | (__| |__| _|
#             |_|  |_|\___/|_|\_|\___/ \___|____|___|
#
#  -------------------------------------------------------------------
#                MONOCLE GATEWAY UNINSTALL SCRIPT
#       COPYRIGHT SHADEBLUE, LLC @ 2018, ALL RIGHTS RESERVED
#  -------------------------------------------------------------------
#
# *********************************************************************

echo "-----------------------------------"
echo "Uninstalling Monocle Gateway"
echo "-----------------------------------"

# REQUIRE 'sudo' PRIVILEGES
if [[ $UID != 0 ]]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

# Uninstall Monocle Gateway as a system service
echo "Stopping Monocle Gateway service daemon"
systemctl stop monocle-gateway    || :
echo "Disabling Monocle Gateway service daemon"
systemctl disable monocle-gateway || :

echo "Removing bind access to system reserved port 443"
setcap -r /usr/local/bin/monocle-gateway || :

# Remove executables files from install location
echo "Uninstalling executables binaries from: '/usr/local/bin'"
rm /usr/local/bin/monocle-gateway || :
rm /usr/local/bin/monocle-proxy   || :

# Remove systemd service file from install location
echo "Uninstall systemd service from: '/etc/systemd/system/monocle-gateway.service'"
rm /etc/systemd/system/monocle-gateway.service || :

# Reload systemd services
echo "Reloading systemd daemon"
systemctl daemon-reload || :

# Remove Monocle service user account
echo "Removing 'monocle' system user account"
deluser --system monocle || :

echo "-----------------------------------"
echo "Monocle Gateway Uninstalled"
echo "-----------------------------------"
