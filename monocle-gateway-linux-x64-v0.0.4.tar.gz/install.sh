#!/bin/bash -e
# *********************************************************************
#              __  __  ___  _  _  ___   ___ _    ___
#             |  \/  |/ _ \| \| |/ _ \ / __| |  | __|
#             | |\/| | (_) | .` | (_) | (__| |__| _|
#             |_|  |_|\___/|_|\_|\___/ \___|____|___|
#
#  -------------------------------------------------------------------
#                 MONOCLE GATEWAY INSTALL SCRIPT
#       COPYRIGHT SHADEBLUE, LLC @ 2018, ALL RIGHTS RESERVED
#  -------------------------------------------------------------------
#
# *********************************************************************

echo "-----------------------------------"
echo "Installing Monocle Gateway"
echo "-----------------------------------"

# REQUIRE 'sudo' PRIVILEGES
if [[ $UID != 0 ]]; then
    echo "Please run this script with sudo:"
    echo "sudo $0 $*"
    exit 1
fi

# Move executables files to install locations
echo "Installing executables binaries to '/usr/local/bin'"
cp monocle-gateway /usr/local/bin/monocle-gateway
cp monocle-proxy /usr/local/bin/monocle-proxy

# Create Monocle service user account to run under
echo "Creating 'monocle' system user account"
id -u monocle &>/dev/null || useradd --system -m monocle

# Create required config directory
echo "Creating configuration directory at '/etc/monocle/'"
mkdir -p /etc/monocle/

# Set group ownership and permissions of config directory
chgrp -f -R monocle /etc/monocle
chmod -f -R g+rw /etc/monocle

# Configure system to allow Monocle-Gateway access to port 443
echo "Configuring bind access to system reserved port 443"
setcap 'cap_net_bind_service=+ep' /usr/local/bin/monocle-gateway

# Install systemd service file to install location
echo "Installing systemd service to '/etc/systemd/system/monocle-gateway.service'"
cp monocle-gateway.service /etc/systemd/system/monocle-gateway.service

# Reload systemd services
echo "Reloading systemd daemon"
systemctl daemon-reload

# Install Monocle Gateway as a system service
echo "Starting Monocle Gateway service daemon"
systemctl start monocle-gateway
echo "Enabling Monocle Gateway service deamon to start automatically"
systemctl enable monocle-gateway

# Check the status of the Monocle service instance
#sudo systemctl status monocle-gateway

echo "-----------------------------------"
echo "Monocle Gateway Installed"
echo "-----------------------------------"
